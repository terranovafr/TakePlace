import com.thoughtworks.xstream.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;

public class ServerRemotoLog {
    public static void main(String[] args){
        System.out.println("Server in esecuzione..");
        try (ServerSocket servs = new ServerSocket(8080, 100)){
            while(true){
                try (Socket sd = servs.accept();
                     DataInputStream din = new DataInputStream(sd.getInputStream());){
                    XStream xs = new XStream();
                    String xml = din.readUTF();
                    File tmp = new File("myfiles/tmp.xml");
                    tmp.createNewFile();
                    Files.write(Paths.get("myfiles/tmp.xml"), xml.getBytes()); //(00)
                    EventoLog log = (EventoLog)xs.fromXML(xml);
                    System.out.println("Ho ricevuto il log relativo all'evento " + log.etichettaEvento + " dall'applicazione " + log.nomeApplicazione + " dall'indirizzo IP " + log.indirizzoIP);
                    boolean result = ValidazioneXML.valida("myfiles/tmp.xml", "myfiles/eventoLog.xsd"); //(00)
                    if(result)
                        System.out.println("La validazione ha avuto successo!");
                    else
                        System.out.println("Validazione non superata!");
                    tmp.delete(); //(00)
                    Files.write(Paths.get("myfiles/logList.xml"), xml.getBytes(), StandardOpenOption.APPEND); //(01)
               } catch (IOException ex){
                    System.out.println(ex.getMessage());
               }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}

/*
(00)
    Salvo l'XML su un file temporaneo così da poter utilizzare il metodo valida della classe ValidazioneXML, che funziona
    fornendo un file XML e un file XSD.
(01)
    Salvo, scriviendo in modalità APPEND, l'XML ricevuto sul file testuale logList.txt
*/